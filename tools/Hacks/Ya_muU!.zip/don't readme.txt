*********************************************************************************
                             Ya_muU 2 Version 3.81b:
*********************************************************************************

Supported clients in SPM: T3D build 54, 55, 56, 57,58, 59, 60, 61, 62, 63, 64, 65
                                    69, 74, 75, 77, 81, 82, 83, 
				    3.0.6e, 3.0.6g, 3.0.6j, 3.0.6m, 3.0.7a, 3.0.7b,                                     
                                        
		   
                   3.0.0g, 3.0.0f, 3.0.0c, 3.0.0a
                   2.0.9, 2.0.9a
                   2.0.8t, 2.0.8s, 2.0.8r, 2.0.8q, 2.0.8o, 2.0.8n, 2.0.8m, 2.0.8l, 
                   2.0.7, 2.0.6c, 2.0.5b, 2.0.5a, 2.0.4d, 2.0.4a, 2.0.4,
                   2.0.3b5, 2.0.3, 2.0.2a, 2.0.2, 2.0.1, 
                   2.0.0g, 2.0.0f, 2.0.0e, 2.0.0d, 2.0.0c, 
                   2.0.0b, 2.0.0a, 2.0.0,
                   1.26.4j, 1.26.4i, 1.26.4b, 1.26.4a, 1.26.4, 
                   1.26.3a, 1.26.3, 1.26.2b, 1.26.2a, 1.26.2,
                   1.26.1, 1.26.0b, 1.26.0a, 1.26.0
                   T2a and Non-T2a

                   3.0.8q, 3.0.8o, 3.0.8j, 3.0.8f, 3.0.8d, 3.0.8a, 3.0.7a, 3.0.7b, 3.0.7d, 3.0.7e
                   3.0.6m, 3.0.6j, 3.0.6h, 3.0.6g, 3.0.6f, 3.0.6e, 3.0.6a, 
                   3.0.5d, 3.0.4p, 3.0.4n, 3.0.4m 
                   3.0.3a, 3.0.2g, 3.0.2f, 3.0.2d, 3.0.2b, 3.0.1a 
                   T2a only.

                   LBR: 3.0.8j, 3.0.8f, 3.0.8d, 3.0.7b, 3.0.7d, 3.0.7e, 3.0.8a, 3.0.8o,3.0.8q (2D+3D)
                                      
                   T2A+LBR+T3D
                   4.0.0a, 4.0.0b, 4.0.0c,4.0.0e, 4.0.0l, 4.0.0o, 4.0.0p, 4.0.0q, 4.0.1a, 4.0.1b, 4.0.2a, 4.0.3b, 4.0.3c
                   4.0.3d, 4.0.3e, 4.0.4a, 4.0.4b, 4.0.5a, 4.0.5b, 4.0.6a, 4.0.7a, 4.0.7b, 4.0.8a, 4.0.9a, 4.0.9b, 4.0.10b,
                   4.0.11a, 4.0.11b, 4.0.11c, 4.0.11e, 4.0.11f
                   5.0.0a, 5.0.0b, 5.0.1a, 5.0.1c,5.0.1d,5.0.1f,5.0.1h,5.0.1i,5.0.1j
                                      
                   AOS:
                   4.0.0b, 4.0.0c, 4.0.0e,4.0.0l, 4.0.0o, 4.0.0p, 4.0.0q, 4.0.1a, 4.0.1b, 4.0.2a, 4.0.3b, 4.0.3c, 4.03d
                   4.0.3e, 4.0.4a, 4.0.4b, 4.0.5a, 4.0.5b, 4.0.6a, 4.0.7a, 4.0.7b, 4.0.8a, 4.0.9a, 4.0.9b, 4.0.10b,
                   4.0.11a, 4.0.11b, 4.0.11c, 4.0.11e, 4.0.11f
                   5.0.0a, 5.0.0b, 5.0.1a, 5.0.1c, 5.0.1d, 5.0.1f,5.0.1h,5.0.1i,5.0.1j
                   
-----------------------------------------------------------------------------------
                   
NEW since version 2.97:

True Multi UO support.
3'rd instance does not crash anymore. (it did since client 4.x and Ya_muU2 versions < 2.97)
It is now possible to start any number of clients.
(if your PC is powerfull enough)
In SPM true multi UO is supported since client 4.03c. In RPM for all.
Important: Undo function of Ya_MuU2 versions prior to 2.97 are not compatible to
those of versions >=2.97.
If changing to a version >=2.97, undo Ya_muU modifications with the old version first
before "upgrading".

---------------------------------------------------------------------------------


official Ya_muU 2 website: stud4.tuwien.ac.at/~e9425109/Ya_muU.htm

---------------------------------------------------------------------------------


********************************************************************************
                                What does it do ?
********************************************************************************

It patches away the stupid check for multiple instances of the client
(files that will be patched: uo.exe, uopatch.exe and client.exe (uotd.exe for UO:3D) ) 

and makes a backup copy of the unpatched files.

********************************************************************************
What does the name stand for ?
********************************************************************************
 
Yet another Multi UO [2]


********************************************************************************
                              How to start/install it ?
********************************************************************************

Unzip the executable-file.
Copy it where ever you want it to have 
Start it.

Click on the patch button to do the actual patching
(the patch button on the left hand side side if you want to patch the 2d client, 
the button on the right hand side if you want to patch the a 3d client)


********************************************************************************
                         Patching modes
********************************************************************************

Yam_uU 2 supports two patching modes

a) Safe patching mode (SPM) -> patching locations are taken from a hardcoded database
   Client version recognition is done via checksum. 
   This is safe because I've tested them all and the locations are verified/done manually.
   Safe patching is the default mode.
   Advantage: nomen est omen, it's safe :)
   Disadvantage: Needs a new verison of Ya_muU 2 any time a new client arrives.
  
b) Risky autopatch mode (RAPM) -> patching locations are calculated by YamuU 2.
   No client version recognition.

   As long as I maintain this program I'd recommand **NOT** to use it.
   Whenever a new client verison arrives, I usually update it quickly
   so that you can use safe patching again.
   Advantage  : **Probably** works for all future clients **without** the need to wait for a new       
   verison.
   Disadvatage: Cant give guarantees that it will work
   Worse: it might fail but won't tell you.

   To toggle between those patching modes, just check the according checkbox 
   (SPM checkbox for safe patching, RAPM checkbox for risky )       

******************************************************************************
                         Undoing Ya_muU 2 patches
******************************************************************************

How does it work ?
Just click on the (2d or 3d client) Undo patching button. 

When OSI patches, you need to remove the Ya_muU patch.
If you don't do that, OSI patching will fail.


********************************************************************************
                             Legal stuff:
********************************************************************************

This software is copyrighted freeware.
Please don't do anything stupid to it or with it.
I'm in NO WAY responsible for any damage the program does.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY, express or implied.  There is no implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE !
I'm particularily not responsible if you get banned for using it.

Ya_muU 2 is NOT approved by OSI and as a consequence you ARE violating the TOS if 
you use it !  YOU HAVE BEEN WARNED !
Using it is at your own risk !
If you value your account dont use it !  
                    
********************************************************************************
                              Problems: 
********************************************************************************

  * Client updates from OSI (= OSI patching) won't work anymore with the patched client 
    Plz don't email about such problems. Thats what the backup is good for
    If a new osi patch arrives (and you have patched it)

    Just undo the Ya_mUU changes.
    Easiest possibility:  re read the point: Undoing Ya_muU patches

    If that fails for whatever reason, do this:

    -> delete client.exe
    -> rename original_client_backup.exe to client.exe
    -> delete uo.exe
    -> rename original_uoexe_backup.exe to uo.exe
    -> delete uopatch.exe
    -> rename original_uopatch_backup.exe to uopatch.exe
    -> start the OSI patching.
    -> wait a few minutes/hours/days till I update Ya_muU 2 to work with the new client in safe mode         
       or use unsafe patching
    -> patch again with Ya_muU 2!.
            

*******************************************************************************
                   Contacting the author
*******************************************************************************

Author: Lord Binary
Email address: Lord_Binary@pspace.at

Feedback, Bugreports, Suggestions
and stuff like that (critique too of course) are always welcome.

Have fun !
