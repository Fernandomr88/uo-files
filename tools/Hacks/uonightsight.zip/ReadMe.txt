                                                         [UO Nightsight v0.1a]
                                                                              
                                                                     [        
                                                                   _#|   ,    
                              _q                                 :g@@|   @    
     _mqHM_qgFp_           >W@@@                                  @@@,  #@y   
    @W@M#@###W@@@           l@##   ___~                           #@@!  ###.  
   q@@@  #@W  @@A|   __[  _pH@@@  q@B"  _#   _qh_     _g!  __     #@#!  "^`   
   #@@F  d@@  @##k _#EW#@@@F]E@@ g@# _@@@@##@# 7#@E #@@@_H@##@L   #h@   ggp   
   @@@k  l@@. 1#@kq#@W'M#E@ {#@@@@} .@@@^TH@#   @@E @#@v@@# 7H@p  gR#^  @@#   
   @N@4  g#   [@@@@@#L q#@F {##@#@@ q##@  @@@   #@  .@F##hRpg@@@. #W#   ##@   
   @##k  AF   #@@#@#@P {##| i#@R'A@_0@@M  N#@    @@ @W ##@#%#W##U #@@: .#@@   
   @@#K  #    #@@4##@P d#@# ]M@@ 6@@ H%%  @@#p   d@#@  3@W@'.  %_ ##@ #;#@@   
   #@#E       l@@k #@#Mm##@Bl#H#  @#L##@@W@@@@,   ##!   #@@#ppgBHL##H@##@@@   
   q@H#       #@@P  `***""""@#5"   H@. "*"*"7"^    "      7"*####""""**"@@*   
   .@@        @B#b          d^     f@@                                  #^    
     *        ^@@`          !       #@@                                 "     
               8                    "##"                                      
                                                                              

..: About this File

ReadMe file for UO Nightsight v0.1a (alpha version)
Date: 15/Feb/2002

..: About UO Nightsight

This tool removes the darkness, so you can see even at nighttime (and in the 
dungeons too) as if it would be daytime. 
There is no need to modify anything, just run UO Nightsight instead of your 
usual "client.exe" to play Ultima Online.

..: Installation

You must copy UO Nightsight in the Ultima Online directory and run 
"UONightsight.exe" instead of the original "client.exe" everytime you want to 
play with "unlimited lights on" :)
This program doesn't need neither extra memory nor extra resources.

NOTE: Remember that default file launched is "client.exe", so if you use a 
client with a different name, just rename it to "client.exe" before execute
UO Nightsight.

..: Compatibility

This version of UO Nightsight was tested on: Windows 95/98/ME/NT/2000/XP 
with some clients of these families: 1.26.x/2.0.x/3.0.x (2D versions)

..: Error Messages

a. "client.exe wasn't found in the current directory!"
   The file "client.exe" is not present in the same directory where 
   UO Nightsight is located. You must copy UO Nightsight in the Ultima Online 
   directory.
b. "Wrong version!"
   The file "client.exe" is not valid or not recognized. Make sure it's not 
   modified by another program and try again. If you can't resolve this error,
   write to me specifying your client version.
c. All other messages regard errors during memory operations or in the 
   "client.exe" structure. If they persist after a reboot, write to me 
   specifying your client version, Windows version and error message, 
   please :)

..: Feedback and WebSite

If you find any bugs or have suggestions, send a mail to:
  Makaveli (vandal@goldrake.com)

You can find the lastest version and get other tools at:
  http://www.vandal.goldrake.com/makaveli/