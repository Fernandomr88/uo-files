
           _/    _/    _/   _/       _/                          
          _/    _/    _/ _/_/_/_/         _/_/_/  _/_/     _/_/_/
         _/    _/    _/   _/       _/    _/    _/    _/ _/    _/ 
        _/    _/    _/   _/       _/    _/    _/    _/ _/    _/  
         _/_/      _/     _/_/   _/    _/    _/    _/   _/_/_/   

            _/_/_/                        _/        _/         
           _/    _/    _/_/   _/    _/   _/_/_/    _/     _/_/ 
          _/    _/  _/    _/ _/    _/   _/    _/  _/   _/_/_/_/
         _/    _/  _/    _/ _/    _/   _/    _/  _/   _/       
        _/_/_/      _/_/     _/_/_/   _/_/_/    _/     _/_/_/v0.1 

Build a second client for playing two Ultima Online games at the same time!
:: by Makaveli

..: About Ultima Double

UODouble is a small tool which lets you use two UO clients at the same time. It must be run from the directory where the client.exe you want to clone is located. It will create another file (clientUD.exe) with the same characteristics as the original client, and running it will execute another session of Ultima Online called Ultima Double. In this way you can easily recognize the two sessions. Of course, you still can use (modified) macroing tools as for the original client.

..: Installation

1. Put the file UODouble.com in the same directory where your client.exe is located (for example your UO directory);
2. Make sure you DON'T have UO running and run the UODouble.com file;
3. If all operations are "Done!", the new client (clientUD.exe) was succesfully created and patched;
4. Launch the file clientUD.exe to run a copy of the UO client.

..: Error Messages

a. "File access error!"
   You have UO running or the file client.exe is not present in the same directory where UODouble.com is located;
b. "Pattern not found!"
   The client.exe file is not valid. Make sure it's not already patched or modified by another program and try again. If error persists write me, please :)

..: Feedback and WebSite

If you find any bugs or have suggestions, send a mail to:
  Makaveli (vandal@goldrake.com)

You can find the lastest version and get other tools at:
  http://www.vandal.goldrake.com/makaveli/