Ultima Online Character Viewer v0.51
====================================

* About
 
The ultima online character viewer is simple tool to build and view customised Ultima Online characters.

See http://homepages.ihug.co.nz/~wverkley/uocview for more uptodate information.


* Installation

You need Ultima Online installed.  I recommend the maximum install if you have room, the minumum install will work though i havnt tested it completely, and the animations will take a fraction more of a sec to load.  You dont need to run UO itself, just copy the viewer into the ultima online directory and run it.


* Bugs

If you can consistently recreate them, please report them to me.


* Todo

- Better support for colors and "hues".
- Fix access violation bugs
- Show the "paper doll"...maybe


Wilfred Verkley
wverkley@ihug.co.nz


Disclaimer:
Im not responsible for any damage or harm this program does.  Like any other freeware program, use it at your own risk.  
