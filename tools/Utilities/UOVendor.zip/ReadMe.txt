Updating 
========
If you are updating from a previous version, take care not to overwrite your data files (these are the files ending '.dat'). The only file you must extract is 'UOVendor.exe', additionaly you can extract the 'MAItem.dat' file as this contains all the magical armour descriptions I could think of, and will save you some typing.

Installing
==========
Along with this readme file are several data files (ending '.dat') and UOVendor.exe (the program file).
Create a new directory and extract all of the files into it.
Then run the UOVendor program using explorer, or create a shortcut to it if you prefer.
You can delete any or all of the data files, if you'd rather start from scratch, or leave them and edit the data provided.

Info
====
The data files are simple comma delimited text files, so you can also edit them notepad and the like.
The data is sent to the game, by sending windows keystroke messages via the operating system to the game window. This means as far as the game is concerned the info could be coming from the keyboard. There is absolutely no interference with the data stream to the game.

Instructions for use are on stratics web site http://uo.stratics.com/
or my own web site http://www.btinternet.com/~paulhowarth/

Or you can contact me
Email : paulhowarth@btinternet.com
ICQ : 74786717

Copyright (C) Paul Howarth 2001
All rights reserved.
