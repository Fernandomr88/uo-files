*Ultima Online Screenshot Utility - Document

** before using

ZIP file contains these files.
uosu.exe	executable file (need to run)
nviolib.dll     jpge dll (need to run)
readme(j).txt	document file (Japanese)
readme(e).txt	document file (English)

** Run
Execute "uosu.exe".

** Further explanation
See support page.
http://www.hh.iij4u.or.jp/~kmatuoka/

** Copyrights and others.
This is a freeware.
Copyright (c) 1998 Katsuyuki Namba (katuyuki@hh.iij4u.or.jp)
I am not responsible for all troubles which may be caused by this software.
You can't upload this software, but you can introduce and set a link to support page.


**Hystory
1.30 - fix the problem causing UO client crush
1.32B - Add an option of JPEG compression / not.
1.33 - fix the font problem on some WIndows 95(Germany)
