*Ultima Online Mage's Staff - Document

This is the software designed for all mages to use mystic power more effectively.

** before using

ZIP file contains these files.
spellmacro.txt	spell macro file
addmacro.bat    adding macro file
magestaf.exe	executable file (need to run)
spells.txt	spell information file (need to run)
readme(j).txt	document file (Japanese)
readme(e).txt	document file (English)

*** for users who use this software for the first time

First, add macros for spellcasting to UO macro.
See this page to further information.
http://www.hh.iij4u.or.jp/~kmatuoka/magestaf/adde.html

*** for users who used previous version.
It may cast "Clumsy" instead of other spell (e.g. summon creature, frame strike)
Make sure that correct spell is assigned in UO.


** Run
Execute "magestaf.exe".

** Further explanation
See support page.
http://mwc.ne.jp/katuyuki/

** Copyrights and others.
This is a freeware.
Copyright (c) 1998 Katsuyuki Namba (katuyuki@po.teleway.ne.jp)
I am not responsible for all troubles which may be caused by this software.
You can't upload this software, but you can introduce and set a link to support page.
