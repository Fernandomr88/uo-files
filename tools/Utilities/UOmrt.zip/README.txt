UO Mages Reagent Tracker V1.1

Created By: Micah Bird  a.k.a. Dev  (or Dev I, II, III, etc..)
		Bird@ij.net

Please send bugs and corrected regeants to me and I will update!
______________________________________________________________
New:  User customizable spells
      Spell Descriptions
      Map of Britannia included (more to come(maybe))
      Setup Program to install
______________________________________________________________

Thanks to:  Ky Yorel (teekell@kilgore.net) for his Spell and reagent 
		list which is where I got a big portion of info.
	    Randolph Mathias for an excellent Brittania map.
            UOVault for their vigilent effort in UO news. 

Hail fellow UO addicts.
	To all PKer's: good for you.
	To all Pk Hunters: good for you.
	To all the whiners: you didnt pay for squat yet, 
			    go cry to your mom until you pay $50+ 
			    and have the right to whine about UO.
___________________________________________________________________
NOTE: only 1 set of data can be saved in this version.

Install:
	-Unzip into a temp diectory.
	-Run the setup program.

Running UO MRT:
	It should be in your Programs menu now....

How it works: (its pretty simple)
	
        Editing Spells:
        1) Highlight the spell you want to alter.
        2) Click the checkboxes next to the reagents that you want 
           the spells to use.
        3) Go to Options and Select Alter Spell (CTRL Z)

        View Spell Description:
        1) Highlight spell.
        2) Go to View/Spell Description

	Adding/Subtracting Reagents:
	1) Select the reagent you want to increase or decrease the 
		amount of by clicking the CheckBox next to the reagent.
	2) Press the + or - button.
	3) Uncheck the CheckBox.	

	Casting:
	1) Select the circle thet the spell is in that you are casting
	2) Select the spell in the SPELL list.
	3) Press CAST and the reagents will be subtracted from 
		your current reagent total.

	Save/load Data:
	1) Go to the Files Menu
	2) Click save or load
	3) Your reagents amount will be saved or loaded from a 
	   player.dat file 
		(note: if you havent saved any data you will 
		 get an error if you try to load data)

	