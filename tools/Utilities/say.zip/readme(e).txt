*Ultima Online Say! - Document

This is the software designed for saying defined words.

** before using

ZIP file contains these files.
UOSay.exe	executable file (need to run)
say-default.txt		data file  (need to run)
readme(j).txt	document file (Japanese)
readme(e).txt	document file (English)

** Run
Execute "UOSay.exe"
First, words are written in Japanese. You won't be read correctly.
Rewrite in English, please.

** Further explanation
See support page.
http://mwc.ne.jp/katuyuki/

** Copyrights and others.
This is a freeware.
Copyright (c) 1998 Katsuyuki Namba (katuyuki@po.teleway.ne.jp)
I am not responsible for all troubles which may be caused by this software.
You can't upload this software, but you can introduce and set a link to support page.

**Hystory
1.00
1.01 - fix the bug that it won't say when you push a button.
1.02 - Add config dialog of UO Caption
1.03 - Add config dialog of Font Size
1.04 - Improve the drawing of buttons.
