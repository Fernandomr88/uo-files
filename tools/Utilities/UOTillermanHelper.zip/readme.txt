Clarence's UO Tillerman Helper
by Clarence, the wandering healer

Copyright � 1999
All Rights Reserved

==================================
Introduction

Clarence's UO Tillerman Helper is a simple utility that allows you to pilot a boat with mouse clicks. The correct keyboard commands are sent to your open Ultima Online window. 
==================================
System Requirements

Windows 95, 98, NT 4.0, ME, or 2000
Ultima Online (duh)

==================================
Installation and Operation Instructions

1) Unzip all files in archive to the same directory. Double click on UOTillermanHelper.exe to begin. 

2) Start Ultima Online, and log into the character you wish to play. Get on your boat. 

3) Press the buttons on Tillerman Helper to send the corresponding commands to UO.

4) Hold the right mouse button down over the boat, and drag to move the utility. Right click the tillerman to bring up the system menu.

==================================
Version History

1.0.0.0     10/28/99 - First release
1.1.0.0     10/31/99 - Fixed bug where 95 wasn't getting line feed commands.
                       Added Switch Window option.
2.0.0.0      3/10/01 - Added support for the Third Dawn client.

==================================
Who did it

Clarence, the wandering healer
Guildmaster, Healers of Chesapeake
******
Jason Babcock
RosebudLTD@Hotmail.com
http://rosebudtech.no-ip.com/

This program is freeware. If you like it, or find a creative use for it, please let me know.

==================================
Origin Support

Currently, this is NOT an approved utility... though I highly doubt anyone would be banned over it.

==================================
Licensing and Copyright

This software is provided AS IS, without warranty, either expressed or implied. Clarence's UO Tillerman Helper is NOT a public domain program. Clarence's UO Tillerman Helper is copyrighted by Rosebud Technologies LTD. This software and all accompanying documentation are protected by United States copyright law and also by international treaty provisions. Rosebud Technologies LTD grants you full license to use this software as intended, and to freely distribute it, so long as it is distributed in its original, unmodified form. Clarence's UO Tillerman Helper may be distributed as part of a collection through written permission from Rosebud Technologies LTD. You may not rent, lease, sell, modify, decompile, disassemble, hex, irk, anger, irritate, or otherwise reverse engineer this program. Any such unauthorized use could cause famine, bubonic plague, El Ni�o, global warming, and a congress controlled by liberal democrats, and will definitely result in the immediate and automatic termination of this license. All rights not expressly granted here are reserved to Rosebud Technologies LTD.

==================================
Contact Us

Rosebud Technologies LTD
18 Sylvan Court
Milford, CT  06460-6650

RosebudLTD@hotmail.com
