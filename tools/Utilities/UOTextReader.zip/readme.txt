Clarence's UO Text Reader
by Clarence, the wandering healer

Copyright � 2000
All Rights Reserved

==================================
Introduction

Clarence's UO Text Reader is a simple utility that takes a text file, and converts it into keystrokes. The keystrokes are then sent to your open Ultima Online window.

What is this good for? Well, want to roleplay a poet or bard? Write your poems and songs in notepad, then flawlessly play them back later... Or do you want to write a book? Click the cursor inside the book, start this utility, and have it fill in the entire text!

==================================
System Requirements

Windows 95, or NT 4.0
Ultima Online (duh)

==================================
Installation and Operation Instructions

1) Unzip all files in archive to the same directory. Double click on UOTextReader.exe to begin.

2) Start Ultima Online, and log into the character you wish to play.

3) Press Browse, and select the text file you wish to read.

4) Type the time delay in milliseconds you want between characters into the delay box.

5) Press the play button to begin reading the file. Use the pause and stop buttons to halt the reading.

6) You can set the window to stay on top from the system menu.

7) If you put a tilde character in your script, text reader will pause at that character. This option, as well as the length of time it pauses, are available from the system menu.

==================================
Version History

1.0.0.0     5/23/99 - First release
1.1.0.0     4/7/00  - Fixed a rare problem with memory retention.
                      Set the default text speed to 150.
                      Removed the unneeded 'Set' button.
                      Added About screen.
                      Added 'Stay On Top' option.
                      Added an option to pause on tilde characters. 
1.2.0.0     7/22/00 - Set the minimum text delay to 0.
                      Added 'Disable Keystrokes While Playing' option.
1.3.0.0     8/3/00  - Added drag and drop file loading support.
                      Added a line length check. Lines longer than UO's
                      80 character limit will generate an error.
1.4.0.0     10/4/00 - Added the option to pause indefinitely on tilde characters.
                      Optimized the windows code for slightly faster processing times.

==================================
Who did it

Clarence, the wandering healer
Guildmaster, Healers of Chesapeake
******
Jason Babcock
RosebudLTD@Hotmail.com
http://www.crosswinds.net/~jbabcock/Rosebud/

This program is freeware. If you like it, or find a creative use for it, please let me know.

==================================
Origin Support

Currently, this is NOT an approved utility... though I highly doubt anyone would be banned over it. It has been submitted for approval.

==================================
Licensing and Copyright

This software is provided AS IS, without warranty, either expressed or implied. Clarence's UO Text Reader is NOT a public domain program. Clarence's UO Text Reader is copyrighted by Rosebud Technologies LTD. This software and all accompanying documentation are protected by United States copyright law and also by international treaty provisions. Rosebud Technologies LTD grants you full license to use this software as intended, and to freely distribute it, so long as it is distributed in its original, unmodified form. Clarence's UO Text Reader may be distributed as part of a collection through written permission from Rosebud Technologies LTD. You may not rent, lease, sell, modify, decompile, disassemble, hex, irk, anger, irritate, or otherwise reverse engineer this program. Any such unauthorized use could cause famine, bubonic plague, El Ni�o, global warming, and a congress controlled by liberal democrats, and will definitely result in the immediate and automatic termination of this license. All rights not expressly granted here are reserved to Rosebud Technologies LTD.

==================================
Contact Us

Rosebud Technologies LTD
18 Sylvan Court
Milford, CT  06460-6650

RosebudLTD@hotmail.com
