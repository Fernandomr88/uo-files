//----------------------------------------------
//	Definition der color_area.txt
//----------------------------------------------
[Anzahl der Farben]
[Farbe in Hexacode aus RGB][TextureCode][low][high][Beschreibung]




//----------------------------------------------
//	Definition der coast_texture.txt
//----------------------------------------------
[Beschreibung]							<- max 25 Zeichen
[Farbe des "Wassers"][Farbe des "Landes"]
[frei]
[Norden][Osten][S�den][Westen]
[NW-Kante][NO-Kante][SO-Kante][SW-Kante]
[NW-Ecke][NO-Ecke][SO-Ecke][SW-Ecke]




//----------------------------------------------
//	Definition der smooth_texture.txt
//----------------------------------------------
[Beschreibung]							<- max 25 Zeichen
[Farbe1][Farbe2][Farbe3(wie Farbe1,aber als neues Terrain)]
[spezial]							<- 1=Rand keine Itemsetzung und H�henhalbierung von MapZ, 2=Berg	
[Norden][Osten][S�den][Westen]
[NW-Kante][NO-Kante][SO-Kante][SW-Kante]
[NW-Ecke][NO-Ecke][SO-Ecke][SW-Ecke]				<- f�llt weg wenn Farbe 3 gesetzt ist




//----------------------------------------------
//	Definition der cliff_texture.txt
//----------------------------------------------
[colorA][colorB][colorC][texture-id1][texture-id2][texture-id3][Beschreibung]




//----------------------------------------------
//	Definition der color_mntn.txt
//----------------------------------------------
[Beschreibung]
[Farbe]
[TextureCode]
[Kuppenfarbe][KuppenTextureCode]				<- Null wenn nicht gesetzt
[H�he1,H�he2]
[H�he3,h�he4]
..................................
[H�he13,H�he14]							<- H�henintervalle, exact 7




//----------------------------------------------
//	Definition der texture.txt
//----------------------------------------------
[Beschreibung]
[Definitionsnummer]
[Anzahl Texturen]
[TextureID1]
[TextureID2]
............
[TextureIDAnzahl]




//----------------------------------------------
//	Definition der smooth_item.txt
//----------------------------------------------
[Beschreibung]							<- max 25 Zeichen
[Farbe1][Farbe2]
[Defaultitem]
[Norden][Osten][S�den][Westen]
[NW-Kante][NO-Kante][SO-Kante][SW-Kante]
[NW-Ecke][NO-Ecke][SO-Ecke][SW-Ecke]




