Ryandor (ryandor@ryandor.com)
Oct 14, 2003

WF4map2.exe (version 6.5.1) for editing map2.mul
WF4map3.exe (version 6.5.2) for editing map3.mul

Statics melt and freeze not working at this time.
No other functional changes at this time.

Support files from WorldForge 6.4 required.

Changes based on 6.4r1 Aeon Edition by Welf
Ryandor (ryandor@ryandor.com)
Oct 14, 2003



