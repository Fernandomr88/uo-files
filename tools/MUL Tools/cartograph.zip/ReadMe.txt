
===============================================================================

the problem with a custom map so far is that anyone using the cartography skill 
will draw maps which show the original uo map. this is because the maps for 
cartography were not taken from "map0.mul", but from a client file called 
"multimap.rle".

with this program, you can create a new multimap from a bitmap.

USAGE - decoding an existing multimap:
"cartograph.exe -decode multimap.rle map.bmp"
this creates a bitmap called "map.bmp" which shows the data from your 
"multimap.rle" file.

USAGE - encoding a new multimap from a bitmap:
"cartograph.exe -encode multimap.rle map.bmp"
this creates a new "multimap.rle" file from the bitmap "map.bmp".
copy the new multimap.rle over your existing file in the uo folder.


NOTE:
the bitmap must be monochrom!!!

===============================================================================
