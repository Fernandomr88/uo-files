Usage: Analyser.exe <Patchfile> [<Outputfile>]

maybe it is of use to create a batchfile containing

...
Analyser.exe patch_22.tdv patch_22.txt
Analyser.exe patch_23.tdv patch_23.txt
...

with one line for each patch.

Varan
varan@uodev.de