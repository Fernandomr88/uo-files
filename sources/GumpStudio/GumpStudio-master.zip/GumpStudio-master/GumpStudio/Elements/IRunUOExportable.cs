﻿namespace GumpStudio.Elements
{
    public interface IRunUOExportable
    {
        string ToRunUOString();
    }
}