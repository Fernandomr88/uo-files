﻿GumpStudioCore,

program for editing and creating Gumps for Ultima Online by Bradley Uffner

Code decompiled and Bradley Uffner himself authorized the release of it.

Bradley, thanks for all.