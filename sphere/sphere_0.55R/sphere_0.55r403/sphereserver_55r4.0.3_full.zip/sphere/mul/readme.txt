place the following mul files in here:

-staidx0.mul
-statics0.mul
-multi.mul
-multi.idx
-verdata.mul
-map0.mul
-hues.mul
-tiledata.mul
