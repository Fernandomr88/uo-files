Congratulations your sphereserver is almost ready to run!

You may want to print these instructions to help you on your way to the last few steps in the configuration process to get your server up and running.




The first step is to modify your sphere.ini, this needs to be set up to handle incoming connection and know a little information on where the sphere files, scripts and UO MUL files are installed.

If you used the default set-up, there is very little to edit in this section.

The first section is the [SERVERS], this needs to be modified with your shard name, IP address and port.

If you are unsure of what your IP is, you can goto http://www.whatismyip.com to get it.

If you are behind a router or firewall, you may need to set port forwarding up to route incoming traffic to the machine that will be running sphereserver.

For more information on this, do a search for �router� on our forums http://www.sphereserver.net or hop into our IRC Chat at irc.sphereserver.net.


Next section is [SPHERE]

In this area, there are many options to change how your Sphere is going to function, however for the basics and getting that shard running, you only need to be concerned with the first few lines for now.

Name=Alter Realm

// Code for servers account application process
//	0=Closed	Closed. Not accepting more.
//	1=EmailApp	Must send email to apply.
//	2=Free		Anyone can just log in and create a full account.
//	3=GuestAuto	You get to be a guest and are automatically sent email with u're new password.
//	4=GuestTrial	You get to be a guest til u're accepted for full by an Admin.
//	5=Other		specified but other ?
//	6=Unspecified	Not specified.
//	7=WebApp	Must fill in a web form and wait for email response
//	8=WebAuto	Must fill in a web form and automatically have access
AccApp=2

// What is the location of the account files
AcctFiles="C:\\Program Files\\sphereserver\\Accounts\\"

// Email address for the administrator of the shard
AdminEmail="youremail@yourisp.com"

// Noted that will show up on the list server for this shard
Notes="UO Sphere Shard"

// List server registration password to secure your shard name and make sure noone else uses it this password should not be changed once set or given out ever
RegPass=

// Server IP address that people will conect to
ServIP="127.0.0.1"

// Connection TCPIP port
ServPort=2593

// URL to the shards home page
URL="www.yourshard.net"

// Directory that log files are kept
LogDir="C:\\Program Files\\sphereserver\\logs\\"

// Set path to all MUL files usually UO install path
MulFiles="C:\\Program Files\\Ultima Online 2D\\"

// Base Directory that contains the script files
ScpFiles="C:\\Program Files\\sphereserver\\"

// Directory that the world save files are kept and made
WorldSave="C:\\Program Files\\sphereserver\\save\\"

// Where the world statics should be saved
WorldStatics="C:\\Program Files\\sphereserver\\sphereStatics.scp\\"




After you are done with this part, you can run your sphereserver  by double clicking the icon on your desktop, once your sphere is started, you will need to set an administrator password, which has not been set by default.

To do this, in the open console window, type the following

.findaccount(administrator).password=xxxxxxxxxxx


The x�s refer to what you want your admin password to be.





The last thing that you will need to do is edit your login.cfg in your UO folder to connect to your server.

LOGINSERVER=yourip,yourshardport#


And that should do it!

Should you have any problems, please do not hesitate to search the forums or go into the IRC chat channel to ask!


And thanks again for choosing sphere!




