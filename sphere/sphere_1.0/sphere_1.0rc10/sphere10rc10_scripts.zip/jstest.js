
function jstestfunc()
{
	return 2
}