In this directory are contained various scripts add-on that should work 
simply unzipping them in the main script directory.

You're free to use them and in case of bugs report them to theyr authors.

We're not responsible for any damage caused by these scripts.
